#include <asf.h>
#include "platform.h"
#include "at_ble_api.h"
#include "console_serial.h"
#include "timer_hw.h"
#include "ble_manager.h"
#include "ble_utils.h"
#include "button.h"
#include "startup_template_app.h"
#include "cscp.h"
#include "cscs.h"
#define MAX_SCAN 1000
//at_ble_status_t _status;
at_ble_tx_power_level_t power;
volatile at_ble_status_t status;
volatile uint8_t scan_count = 0;
at_ble_scan_info_t scan_info[MAX_SCAN];
#define APP_STACK_SIZE  (1024)

volatile unsigned char app_stack_patch[APP_STACK_SIZE];

/* Received notification data structure */
csc_report_ntf_t recv_ntf_info;
uint8_t i=0;
csc_report_ntf_t result[100];
/* Data length to be send over the air */
uint16_t send_length = 0;
	float *temp;
	float f;
	uint8_t *status_esp;
	int a;
/* Buffer data to be send over the air */
uint8_t send_data[APP_TX_BUF_SIZE];
volatile static bool read_complete_flag = false;
volatile static bool write_complete_flag = false;
struct uart_module uart_instance;
static void ble_advertise (void)
{
	at_ble_addr_t device_req;
	device_req.type=AT_BLE_ADDRESS_PUBLIC;
	device_req.addr[0]=0xBB;
	device_req.addr[1]=0x5D;
	device_req.addr[2]=0xF3;
	device_req.addr[3]=0x05;
	device_req.addr[4]=0xF0;
	device_req.addr[5]=0xF8;
	printf("\nAssignment 2.1 : Start Advertising");
	status = ble_advertisement_data_set();
	if(status != AT_BLE_SUCCESS)
	{
		printf("\n\r## Advertisement data set failed : error %x",status);
		while(1);
	}
	/* Start of advertisement */
	status = at_ble_adv_start(AT_BLE_ADV_TYPE_UNDIRECTED,
	AT_BLE_ADV_GEN_DISCOVERABLE,
	NULL,
	AT_BLE_ADV_FP_ANY,
	1600,
	0,
	false);
	if(status != AT_BLE_SUCCESS)
	{
		printf("\n\r## Advertisement data set failed : error %x",status);
		while(1);
	}
}
at_ble_status_t ble_scan_handler(void *params)
{
	at_ble_scan_info_t *scan_param;
	scan_param = (at_ble_scan_info_t *)params;
	//memcpy((uint8_t *)&scan_info[scan_count], scan_param, sizeof(at_ble_scan_info_t));
	printf("RSSI is %d device address is 0x%02X%02X%02X%02X%02X%02X",scan_param->rssi,scan_param->dev_addr.addr[5],
	scan_param->dev_addr.addr[4],
	scan_param->dev_addr.addr[3],
	scan_param->dev_addr.addr[2],
	scan_param->dev_addr.addr[1],
	scan_param->dev_addr.addr[0]);
	status = at_ble_scan_stop();
	if(status== AT_BLE_SUCCESS)
	printf("Scanning stopped and advertising started");
	ble_advertise();
	return AT_BLE_SUCCESS;
}

/* Callback registered for AT_BLE_CONNECTED event*/
static at_ble_status_t ble_paired_cb (void *param)
{
	//at_ble_pair_done_t *pair_params = param;
	printf("\nAssignment 3.2: Application connected ");
	//ALL_UNUSED(param);
	return AT_BLE_SUCCESS;
}
/* Callback registered for AT_BLE_DISCONNECTED event */
static at_ble_status_t ble_disconnected_cb (void *param)
{
	at_ble_addr_t device_req1;
	device_req1.type=AT_BLE_ADDRESS_PUBLIC;
	device_req1.addr[0]=0x16;
	device_req1.addr[1]=0x5A;
	device_req1.addr[2]=0xF3;
	device_req1.addr[3]=0x05;
	device_req1.addr[4]=0xF0;
	device_req1.addr[5]=0xF8;
	at_ble_connection_params_t gap_conn_parameter1;
	gap_conn_parameter1.con_intv_min = GAP_CONN_INTERVAL_MIN;
	gap_conn_parameter1.con_intv_max = GAP_CONN_INTERVAL_MAX;
	gap_conn_parameter1.con_latency = GAP_CONN_SLAVE_LATENCY;
	gap_conn_parameter1.ce_len_min = GAP_CE_LEN_MIN;
	gap_conn_parameter1.ce_len_max = GAP_CE_LEN_MAX;
	gap_conn_parameter1.superv_to = GAP_SUPERVISION_TIMOUT;
	printf("\nAssignment 3.2: Application disconnected ");
	status=at_ble_connect(&device_req1,1,
	SCAN_INTERVAL,SCAN_WINDOW, &gap_conn_parameter1);
	//status = at_ble_whitelist_add(&device_req);
	if (status != AT_BLE_SUCCESS) {
		printf("\n##Error in adding the ble connect");
	}
}
static const ble_event_callback_t ble_gap_handle[] = {
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ble_paired_cb,
	ble_disconnected_cb,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
};

static void register_ble_callbacks (void)
{
	/* Register GAP Callbacks */
	printf("\nAssignment 3.2: Register bluetooth events callbacks");
	status = ble_mgr_events_callback_handler(REGISTER_CALL_BACK,
	BLE_GAP_EVENT_TYPE,ble_gap_handle);
	if (status != true) {
		printf("\n##Error when Registering SAMB11 gap callbacks");
	}
}
static void csc_app_recv_buf(uint8_t *recv_data, uint8_t recv_len)
{
	/*uint16_t ind = 0;
    if (recv_len){
        for (ind = 0; ind < recv_len; ind++){
            DBG_LOG_CONT("%c", recv_data[ind]);
        }
        DBG_LOG("\r\n");
    }*/
	temp=(float *)recv_data;
	//DBG_LOG("%g",*temp);
		
}
/* Callback called for new data from remote device */
static void csc_prf_report_ntf_cb(csc_report_ntf_t *report_info)
{
	memcpy((uint8_t *)&result[i], report_info, sizeof(csc_report_ntf_t));
    csc_app_recv_buf(report_info->recv_buff, report_info->recv_buff_len);
}
//static void uart_write_complete_callback(struct uart_module *const module)
//{
	//write_complete_flag = true;
//}
//static void uart_read_complete_callback(struct uart_module *const module)
//{
   ////printf("%s",*(status_esp));	
 ////printf("%s",status_esp);
 //// printf("I Read it");
	//read_complete_flag = true;
//}

//! [callback_functions]

//! [setup]
//static void configure_uart(void)
//{
	////! [setup_config]
	//struct uart_config config_uart;
	////! [setup_config]
	////! [setup_config_defaults]
	//uart_get_config_defaults(&config_uart);
	////! [setup_config_defaults]
//
	////! [setup_change_config]
	//config_uart.baud_rate = 9600;
	//config_uart.pin_number_pad[0] = EDBG_CDC_SERCOM_PIN_PAD0;
	//config_uart.pin_number_pad[1] = EDBG_CDC_SERCOM_PIN_PAD1;
	//config_uart.pin_number_pad[2] = EDBG_CDC_SERCOM_PIN_PAD2;
	//config_uart.pin_number_pad[3] = EDBG_CDC_SERCOM_PIN_PAD3;
	//
	//config_uart.pinmux_sel_pad[0] = EDBG_CDC_SERCOM_MUX_PAD0;
	//config_uart.pinmux_sel_pad[1] = EDBG_CDC_SERCOM_MUX_PAD1;
	//config_uart.pinmux_sel_pad[2] = EDBG_CDC_SERCOM_MUX_PAD2;
	//config_uart.pinmux_sel_pad[3] = EDBG_CDC_SERCOM_MUX_PAD3;
	////! [setup_change_config]
//
	////! [setup_set_config]
	//while (uart_init(&uart_instance,
	//EDBG_CDC_MODULE, &config_uart) != STATUS_OK) {
	//}
	////! [setup_set_config]
//}
//void gpio_config()
//{
	//struct gpio_config config_gpio_pin;
	//gpio_get_config_defaults(&config_gpio_pin);
	//config_gpio_pin.direction=GPIO_PIN_DIR_OUTPUT;
	//gpio_pin_set_config(PIN_LP_GPIO_20,&config_gpio_pin);
	////gpio_pin_set_config(LP_ ,&config_gpio_pin);
//}

int main (void)
{
	
	at_ble_addr_t device_req;
	//char TXBuffer[43];
	//char TXBuffer1[7];
	//char TXBuffer2[10];
	//char TXbuff[4];
	//TCP_Connectchar TXBuffer2[1024];
	//char TXBuffer3[169];
	device_req.type=AT_BLE_ADDRESS_PUBLIC;
	device_req.addr[0]=0x16;
	device_req.addr[1]=0x5A;
	device_req.addr[2]=0xF3;
	device_req.addr[3]=0x05;
	device_req.addr[4]=0xF0;
	device_req.addr[5]=0xF8;
	//uint8_t start_esp[]="AT+CWJAP=\"Bhallaji's iPhone","12345678\r\n";
	//char *ssid = "Bhallaji's iPhone";
	//char *ssid = "Bhallaji's iPhone";
//	char *password = "12345678";
	//char *ssid = "Mounika Reddy's iPhone";
	//char *password = "12345678";
//	char *IPaddress = "54.86.132.254";
	//170.20.10.11
	//12000
	//int k = 0;
	//char TCP_Connect[]="AT+CIPSTART=\"TCP\",\"54.86.132.254\",80\r\n";
	//char TCP_Connect[]="AT+CIPSTART=\"TCP\",\"170.20.10.11\",12000\r\n";
	//char *fetch = "PUSH /data.sparkfun.com/input/n1n14jAGrvT09dW7lqvQ?private_key=MomoMZGqgyHA4wg7yYrK&light_lux=0&sound_db=4.05&temp_celcius=8.6 HTTP/1.1\r\nHost:data.sparkfun.com\r\n\r\n";
	 // char *fetch = "PUSH /data.sparkfun.com/input/EJnQMq2O62Tn3dgljnzR?private_key=dqDR5d7P47HbZDE7AbxK&light_lux=2.79&sound_db=29.51&temp_c=15.62 HTTP/1.1\r\nHost:data.sparkfun.com\r\n\r\n";
	 //char *fetch = "GET L\n";
	//sprintf((char*)TXBuffer, "AT+CWJAP=\"%s\",\"%s\"\r\n", ssid, password); 
	//sprintf((char*)TXBuffer2, "AT+CWQAP\r\n"); 
	//sprintf((char*)TXbuff, "AT\r\n");
	//sprintf((char*)TXBuffer1, "AT+RST\r\n");
	//sprintf((char*)TXBuffer2, TCP_Connect);
	//AT+CIPSTART="TCP","54.86.132.254",80\r\n
	//a = strlen(fetch);
	 //sprintf((char*)TXBuffer3, "AT+CIPSEND=%d\r\n", 169);
	 //a = strlen(fetch);
	//TXBuffer[0] = 'A';
	platform_driver_init();
	acquire_sleep_lock();
	/* Initialize serial console */
	//gpio_config();
	serial_console_init();
	/* Hardware timer */
	hw_timer_init();
	
	//configure_uart();
	
	//uart_register_callback(&uart_instance, uart_write_complete_callback,
	//UART_TX_COMPLETE);
	//uart_enable_callback(&uart_instance, UART_TX_COMPLETE);
	//uart_register_callback(&uart_instance, uart_read_complete_callback,
	//UART_RX_COMPLETE);
	//uart_enable_callback(&uart_instance, UART_RX_COMPLETE);
	//while(1)
	//{
		
		//AT+CWQAP
//		uart_write_buffer_job(&uart_instance, TXBuffer2, sizeof(TXBuffer2));
//		while(!write_complete_flag);

//		uart_read_buffer_job(&uart_instance, status_esp, sizeof(status_esp));
//		while (!read_complete_flag);
//		while (k <8000)
//		{
//			k++;
//		}
//		k = 0;
		
//AT		
//	uart_write_buffer_job(&uart_instance, TXbuff, sizeof(TXbuff));
//		while(!write_complete_flag);
	
//	uart_read_buffer_job(&uart_instance, status_esp, sizeof(status_esp));
//	while (!read_complete_flag);
// while(1)
// {
	 	
//AT+RST
//	uart_write_buffer_job(&uart_instance, TXBuffer1, sizeof(TXBuffer1));
//	while(!write_complete_flag);
	
//	uart_read_buffer_job(&uart_instance, status_esp, sizeof(status_esp));
//	while (!read_complete_flag);


//AT+CWJAP
//cpu_irq_disable();
//uart_write_buffer_job(&uart_instance, TXBuffer, sizeof(TXBuffer));
//while(!write_complete_flag);
//
//uart_read_buffer_job(&uart_instance, status_esp, sizeof(status_esp));
//while (!read_complete_flag);
	
//AT+CWQAP	
//	uart_write_buffer_job(&uart_instance, TXBuffer2, sizeof(TXBuffer2));
//	while(!write_complete_flag);

	//uart_read_buffer_job(&uart_instance, status_esp, sizeof(status_esp));
    //while (!read_complete_flag);	
	//	while (k <8000)
	//		{
	//			k++;
	//		}
	//		k = 0;
			
				


	//while (k <80000000)
 //	{
  //   	k++;
//	}
//	k = 0;
//	cpu_irq_enable();

 //}
//AT+CIPSTART	
//	uart_write_buffer_job(&uart_instance, TCP_Connect, sizeof(TCP_Connect));
//	while(!write_complete_flag);

//	uart_read_buffer_job(&uart_instance, status_esp, sizeof(status_esp));
//	while (!read_complete_flag);
//		while (k <8000)
//		{
//			k++;
//		}
//		k = 0;
//AT+CIPSEND	
//	uart_write_buffer_job(&uart_instance, TXBuffer3, sizeof(TXBuffer3));
//	while(!write_complete_flag);

//	uart_read_buffer_job(&uart_instance, status_esp, sizeof(status_esp));
//	while (!read_complete_flag);
//	while (k <8000)
//	{
//		k++;
//	}
//	k = 0;
//Sending PUSH
	
//		uart_write_buffer_job(&uart_instance, fetch, 169);
//		while(!write_complete_flag);

	//	uart_read_buffer_job(&uart_instance, status_esp, sizeof(status_esp));
	//	while (!read_complete_flag);
//			while (k <8000000)
//			{
//				k++;
//			}
	//}
	
//	k = 0;
	//while(1);
	//for(int j=0;j<8000000;j++);
	////}
	printf("\n\rSAMB11 BLE Application");
	/* initialize the BLE chip and Set the Device Address */
	ble_device_init(NULL);
	if((status = at_ble_tx_power_set(AT_BLE_TX_PWR_LVL_POS_01_DB)) != AT_BLE_SUCCESS)
	{
		printf("BLE at_ble_tx_power_set failed =0x%x\n", status);
	}
	else
	{
		printf("Assignment 5: at_ble_tx_power_set = 0x%x\n", 
		AT_BLE_TX_PWR_LVL_POS_01_DB);
	}
	power = 0;
	if((status = at_ble_tx_power_get(&power)) != AT_BLE_SUCCESS)
	{
		printf("BLE at_ble_tx_power_get failed =0x%x\n", status);
	}
	else
	{
		printf("Assignment 4: at_ble_tx_power_get = 0x%x\n", power);
	}
	csc_prf_init(NULL);
	at_ble_connection_params_t gap_conn_parameter;
	gap_conn_parameter.con_intv_min = GAP_CONN_INTERVAL_MIN;
	gap_conn_parameter.con_intv_max = GAP_CONN_INTERVAL_MAX;
	gap_conn_parameter.con_latency = GAP_CONN_SLAVE_LATENCY;
	gap_conn_parameter.ce_len_min = GAP_CE_LEN_MIN;
	gap_conn_parameter.ce_len_max = GAP_CE_LEN_MAX;
	gap_conn_parameter.superv_to = GAP_SUPERVISION_TIMOUT;
	register_ble_callbacks();
	printf("\n\r waiting for the device ");
	status=at_ble_connect(&device_req,1,
	SCAN_INTERVAL,SCAN_WINDOW, &gap_conn_parameter);
	//status = at_ble_whitelist_add(&device_req);
	if (status != AT_BLE_SUCCESS) {
		printf("\n##Error in adding the ble connect");
	}
	notify_recv_ntf_handler(csc_prf_report_ntf_cb);
	/* set Beacon advertisement data */
	//at_ble_scan_start(8000,1600,0x0000,AT_BLE_SCAN_ACTIVE,AT_BLE_SCAN_OBSERVER_MODE,true,false);
	//printf("Assignment 3: BLE Beacon Scan Started\n");
	//release_sleep_lock();
	while(true){
		ble_event_task(0xFFFFFFFF);
	}
	
}