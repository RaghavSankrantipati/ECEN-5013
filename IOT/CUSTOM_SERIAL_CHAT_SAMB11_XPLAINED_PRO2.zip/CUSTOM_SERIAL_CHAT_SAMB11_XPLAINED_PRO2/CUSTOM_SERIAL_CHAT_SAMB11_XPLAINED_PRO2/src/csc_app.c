/*code is written based on the ATMEL Tutorial and Example codes given by ATMEL SAMB11*/
#include <asf.h>
#include "platform.h"
#include "at_ble_api.h"
#include "console_serial.h"
#include "timer_hw.h"
#include "ble_manager.h"
#include "ble_utils.h"
#include "button.h"
#include "cscp.h"
#include "cscs.h"
#include "csc_app.h"
#include <string.h>
#include <stdio.h>
/**global variables**/
volatile at_ble_status_t status;
at_ble_handle_t htpt_conn_handle;
volatile bool Timer_Flag = false;
volatile bool Temp_Notification_Flag = false;
/** if temperature required in F*/
//#define HTPT_FAHRENHEIT
struct uart_module uart_instance;
struct dma_resource uart_dma_resource_tx;
struct dma_resource uart_dma_resource_rx;
#define BUFFER_LEN    5
static uint8_t string[BUFFER_LEN];
struct dma_descriptor example_descriptor_tx;
struct dma_descriptor example_descriptor_rx;
float* temp;
float x;
void gpioconfig();
#define APP_STACK_SIZE  (1024)
volatile unsigned char app_stack_patch[APP_STACK_SIZE];
/* Received notification data structure */
csc_report_ntf_t recv_ntf_info;
at_ble_tx_power_level_t power;
/* Data length to be send over the air */
uint16_t send_length = 0;

/* Buffer data to be send over the air */
uint8_t send_data[APP_TX_BUF_SIZE];
/* configuration of GPIO**/
void gpioconfig()
{
	struct gpio_config config_gpio_pin;
	gpio_get_config_defaults(&config_gpio_pin);
	//config_gpio_pin.input_pull=GPIO_PIN_PULL_DOWN;
	config_gpio_pin.direction = GPIO_PIN_DIR_OUTPUT;
	gpio_pin_set_config(LED_0_PIN, &config_gpio_pin);
}
/** call back function of TX**/
static void transfer_done_tx(struct dma_resource* const resource )
{
	dma_start_transfer_job(&uart_dma_resource_rx);
}
/** call back function of RX**/
 static void transfer_done_rx(struct dma_resource* const resource )
{
	//dma_start_transfer_job(&uart_dma_resource_tx);
	if(string[0]!=76)
	{
		#undef STATE
		temp=(float *)string ;
	}
	if(string[4]==78)
	{
		#define STATE
		*temp=x;
		gpio_pin_set_output_level(LED_0_PIN, 0);
	}
	else if(string[4]==70)
	{
		*temp=x;
		#define STATE
		gpio_pin_set_output_level(LED_0_PIN, 1);
	}
	printf("in dma callback %3.2f",*temp);
	send_plf_int_msg_ind(DMA_CALLBACK_TRANSFER_DONE, PROV_DMA_CTRL_CH0_CMD_REG3_CMD_SET_INT, string, 5);
	dma_start_transfer_job(&uart_dma_resource_rx);
}
/**allocating the resource for TX**/
static void configure_dma_resource_tx(struct dma_resource *resource)
{
	//! [setup_tx_1]
	struct dma_resource_config config;
	//! [setup_tx_1]

	//! [setup_tx_2]
	dma_get_config_defaults(&config);
	//! [setup_tx_2]
	//! [setup_tx_3]
	config.des.periph = UART0TX_DMA_PERIPHERAL;	
	config.des.enable_inc_addr = false;
	config.src.periph = UART0TX_DMA_PERIPHERAL;
	//! [setup_tx_3]

	//! [setup_tx_4]
	dma_allocate(resource, &config);
	//! [setup_tx_4]
}
//! [config_dma_resource_tx]

//! [setup_dma_transfer_tx_descriptor]
static void setup_transfer_descriptor_tx(struct dma_descriptor *descriptor)
{

	//! [setup_tx_5]
	dma_descriptor_get_config_defaults(descriptor);
	//! [setup_tx_5]
	//! [setup_tx_6]
	descriptor->buffer_size = BUFFER_LEN;
	descriptor->read_start_addr = (uint32_t)string;
	descriptor->write_start_addr =
	(uint32_t)(&uart_instance.hw->TRANSMIT_DATA.reg);
	//! [setup_tx_6]
}
//! [setup_dma_transfer_tx_descriptor]

//! [config_dma_resource_rx]
/**allocating the resource for TX**/
static void configure_dma_resource_rx(struct dma_resource *resource)
{
	//! [setup_rx_1]
	struct dma_resource_config config;
	//! [setup_rx_1]

	//! [setup_rx_2]
	dma_get_config_defaults(&config);
	//! [setup_rx_2]

	//! [setup_rx_3]
	config.src.periph = UART0RX_DMA_PERIPHERAL;
		
	config.src.enable_inc_addr = false;
	config.src.periph_delay = 1;
	//! [setup_rx_3]

	//! [setup_rx_4]
	dma_allocate(resource, &config);
	//! [setup_rx_4]
}
//! [config_dma_resource_rx]

//! [setup_dma_transfer_rx_descriptor]
static void setup_transfer_descriptor_rx(struct dma_descriptor *descriptor)
{
	//! [setup_rx_5]
	dma_descriptor_get_config_defaults(descriptor);
	//! [setup_rx_5]

	//! [setup_tx_6]
	descriptor->buffer_size = BUFFER_LEN;
	descriptor->read_start_addr =
	(uint32_t)(&uart_instance.hw->RECEIVE_DATA.reg);
	descriptor->write_start_addr = (uint32_t)string;
	//! [setup_tx_6]
}
//! [setup_dma_transfer_rx_descriptor]

//! [setup_usart]
static void configure_usart(void)
{
	//! [setup_config]
	struct uart_config config_uart;
	//! [setup_config]

	//! [setup_config_defaults]
	uart_get_config_defaults(&config_uart);
	//! [setup_config_defaults]

	//! [setup_change_config]
	config_uart.baud_rate = 9600;
	config_uart.pin_number_pad[0] = EDBG_CDC_SERCOM_PIN_PAD0;
	config_uart.pin_number_pad[1] = EDBG_CDC_SERCOM_PIN_PAD1;
	config_uart.pin_number_pad[2] = EDBG_CDC_SERCOM_PIN_PAD2;
	config_uart.pin_number_pad[3] = EDBG_CDC_SERCOM_PIN_PAD3;
	config_uart.pinmux_sel_pad[0] = EDBG_CDC_SERCOM_MUX_PAD0;
	config_uart.pinmux_sel_pad[1] = EDBG_CDC_SERCOM_MUX_PAD1;
	config_uart.pinmux_sel_pad[2] = EDBG_CDC_SERCOM_MUX_PAD2;
	config_uart.pinmux_sel_pad[3] = EDBG_CDC_SERCOM_MUX_PAD3;
	

	//! [setup_change_config]

	//! [setup_set_config]
	while (uart_init(&uart_instance,
	EDBG_CDC_MODULE, &config_uart) != STATUS_OK) {
	}
	//! [setup_set_config]

	//! [enable_interrupt]
	uart_enable_transmit_dma(&uart_instance);
	uart_enable_receive_dma(&uart_instance);
	//! [enable_interrupt]
}
//! [setup_usart]

//! [setup_callback]
static void configure_dma_callback(void)
{
	//! [setup_callback_register]
	dma_register_callback(&uart_dma_resource_tx, transfer_done_tx, DMA_CALLBACK_TRANSFER_DONE);
	dma_register_callback(&uart_dma_resource_rx, transfer_done_rx, DMA_CALLBACK_TRANSFER_DONE);
	//! [setup_callback_register]

	//! [setup_enable_callback]
	dma_enable_callback(&uart_dma_resource_tx, DMA_CALLBACK_TRANSFER_DONE);
	dma_enable_callback(&uart_dma_resource_rx, DMA_CALLBACK_TRANSFER_DONE);
	//! [setup_enable_callback]

	//! [enable_inic]
	NVIC_EnableIRQ(PROV_DMA_CTRL0_IRQn);
	//! [enable_inic]
}


/* Timer callback */
static void timer_callback_handler(void)
{
	/* Stop timer */
	hw_timer_stop();
	/* Set timer Alarm flag */
	Timer_Flag = true;
	/* Restart Timer */
	hw_timer_start(10);
}

/** bLE advertise**/
static void ble_advertise (void)
{
	at_ble_addr_t device_req;
	device_req.type=AT_BLE_ADDRESS_PUBLIC;
	device_req.addr[0]=0x4E;
	device_req.addr[1]=0x69;
	device_req.addr[2]=0x6B;
	device_req.addr[3]=0x70;
	device_req.addr[4]=0xF3;
	device_req.addr[5]=0x5C;
	printf("\nAssignment 2.1 : Start Advertising");
	status = ble_advertisement_data_set();

	if(status != AT_BLE_SUCCESS)
	{
		printf("\n\r## Advertisement data set failed : error %x",status);
		while(1);
	}
	/* Start of advertisement */
	status = at_ble_adv_start(AT_BLE_ADV_TYPE_DIRECTED,
	AT_BLE_ADV_GEN_DISCOVERABLE,
	&device_req,
	AT_BLE_ADV_FP_ANY,
	3200,
	0,
	0);
	if(status != AT_BLE_SUCCESS)
	{
		printf("\n\r## Advertisement data set failed : error %x",status);
		while(1);
	}
}
/* Callback registered for AT_BLE_CONNECTED event*/
static at_ble_status_t ble_paired_cb (void *param)
{
	//at_ble_pair_done_t *pair_params = param;
	printf("\nAssignment 3.2: Application paired ");
	
	return AT_BLE_SUCCESS;
}
/* Callback registered for AT_BLE_DISCONNECTED event */
static at_ble_status_t ble_disconnected_cb (void *param)
{
	printf("\nAssignment 3.2: Application disconnected ");
	ble_advertise();
	ALL_UNUSED(param);return AT_BLE_SUCCESS;
}
static const ble_event_callback_t app_gap_cb[] = {

	NULL, // AT_BLE_UNDEFINED_EVENT
	NULL, // AT_BLE_SCAN_INFO
	NULL, // AT_BLE_SCAN_REPORT
	NULL, // AT_BLE_ADV_REPORT
	NULL, // AT_BLE_RAND_ADDR_CHANGED
	NULL, // AT_BLE_CONNECTED
	ble_disconnected_cb, // AT_BLE_DISCONNECTED
	NULL, // AT_BLE_CONN_PARAM_UPDATE_DONE
	NULL, // AT_BLE_CONN_PARAM_UPDATE_REQUEST
	ble_paired_cb, // AT_BLE_PAIR_DONE
	NULL, // AT_BLE_PAIR_REQUEST
	NULL, // AT_BLE_SLAVE_SEC_REQUEST
	NULL, // AT_BLE_PAIR_KEY_REQUEST
	NULL, // AT_BLE_ENCRYPTION_REQUEST
	NULL, // AT_BLE_ENCRYPTION_STATUS_CHANGED
	NULL, // AT_BLE_RESOLV_RAND_ADDR_STATUS
	NULL, // AT_BLE_SIGN_COUNTERS_IND
	NULL, // AT_BLE_PEER_ATT_INFO_IND
	NULL // AT_BLE_CON_CHANNEL_MAP_IND
};

/* Register GAP callbacks at BLE manager level*/
static void register_ble_callbacks (void)
{
	/* Register GAP Callbacks */
	printf("\nAssignment 3.2: Register bluetooth events callbacks");
	status = ble_mgr_events_callback_handler(REGISTER_CALL_BACK,\
	BLE_GAP_EVENT_TYPE,app_gap_cb);
	if (status != true) {
		printf("\n##Error when Registering SAMB11 gap callbacks");
	}
}
/* Function used for send data */
static void csc_app_send_buf(void)
{
	uint16_t plf_event_type;
	uint16_t plf_event_data_len;
	uint8_t plf_event_data[APP_TX_BUF_SIZE] = {0, };

	platform_event_get(&plf_event_type, plf_event_data, &plf_event_data_len);
	
	if(plf_event_type == ((PROV_DMA_CTRL_CH0_CMD_REG3_CMD_SET_INT << 8) | DMA_CALLBACK_TRANSFER_DONE)) {
		DBG_LOG("in the loop");
		csc_prf_send_data(plf_event_data, plf_event_data_len);
	}

}
int main (void)
{
	platform_driver_init();
	acquire_sleep_lock();
	/* Initialize serial console */
	serial_console_init();
	DBG_LOG("Initializing Custom Serial Chat Application");
	/* Initialize the buffer address and buffer length based on user input */
	csc_prf_buf_init(temp, APP_TX_BUF_SIZE);
	/*initilase gpio module*/
	gpioconfig();
	/* Initialize the hardware timer */
	hw_timer_init();
	/* Register the callback */
	hw_timer_register_callback(timer_callback_handler);
	/* Start timer */
	hw_timer_start(1);
	/* initialize the BLE chip and Set the Device Address */
	ble_device_init(NULL);
	if((status = at_ble_tx_power_set(AT_BLE_TX_PWR_LVL_POS_01_DB)) != AT_BLE_SUCCESS)
	{
		printf("BLE at_ble_tx_power_set failed =0x%x\n", status);
	}
	else
	{
		printf("Assignment 5: at_ble_tx_power_set = 0x%x\n",
		AT_BLE_TX_PWR_LVL_POS_01_DB);
	}
	power = 0;
	if((status = at_ble_tx_power_get(&power)) != AT_BLE_SUCCESS)
	{
		printf("BLE at_ble_tx_power_get failed =0x%x\n", status);
	}
	else
	{
		printf("Assignment 4: at_ble_tx_power_get = 0x%x\n", power);
	}
	csc_prf_init(NULL);
	/* Initialize the temperature sensor */
	//at30tse_init();
	configure_usart();
	configure_dma_resource_tx(&uart_dma_resource_tx);
	configure_dma_resource_rx(&uart_dma_resource_rx);
	setup_transfer_descriptor_tx(&example_descriptor_tx);
	setup_transfer_descriptor_rx(&example_descriptor_rx);
	dma_add_descriptor(&uart_dma_resource_tx, &example_descriptor_tx);
	dma_add_descriptor(&uart_dma_resource_rx, &example_descriptor_rx);
	configure_dma_callback();
	dma_start_transfer_job(&uart_dma_resource_rx);
	/* configure the temperature sensor ADC */
	//at30tse_write_config_register(AT30TSE_CONFIG_RES(AT30TSE_CONFIG_RES_12_bit));
	/* read the temperature from the sensor */
	//htp_temperature_read();
	/* Initialize the htp service */
	/* Register Bluetooth events Callbacks */
	register_ble_callbacks();
	/* Start Advertising process */
	ble_advertise();
	/* Register the notification handler */
	//notify_recv_ntf_handler(csc_prf_report_ntf_cb);
	
	/* Register the user event handler */
	register_ble_user_event_cb(csc_app_send_buf);
	
	//register_uart_callback(uart_rx_callback);
	while(true) {
		ble_event_task(0x655);
	}
}
